import { Router } from "express";
import {
  runForecastEngine,
  runPolicyEngine,
  runSourceAttributionEngine,
  runAdvisoryEngine,
  runExposureEngine,
  runCadrEngine,
  runInstitutionalEngine,
  generatePolicyBriefingReport,
  composeEmergencyAlert,
  generateVoiceScript,
  runChatEngine,
  clampNumber,
  sanitizeString,
} from "../ai-engine";
import { escapeHtml, isValidEmail, isValidPhone } from "../middleware/security";

interface AlertSubscription {
  id: string;
  phoneNumber: string;
  emailAddress: string;
  enableSms: boolean;
  enableEmail: boolean;
  alertOnSevereAqi: boolean;
  aqiThreshold: number;
  alertOnGrapEscalation: boolean;
  alertOnNocturnalInversion: boolean;
  alertOnStubbleSurge: boolean;
  dailyMorningDigest: boolean;
  selectedStationIds: string[];
  preferredLanguage: "EN" | "HI";
  updatedAt: string;
}

export function createApiRouter(): Router {
  const router = Router();

  let activeSubscription: AlertSubscription = {
    id: "sub-user-01",
    phoneNumber: "+91 98712 34567",
    emailAddress: "citizen@delhi.gov.in",
    enableSms: true,
    enableEmail: true,
    alertOnSevereAqi: true,
    aqiThreshold: 300,
    alertOnGrapEscalation: true,
    alertOnNocturnalInversion: true,
    alertOnStubbleSurge: true,
    dailyMorningDigest: true,
    selectedStationIds: ["all"],
    preferredLanguage: "EN",
    updatedAt: new Date().toISOString(),
  };

  let dispatchedAlertHistory: Array<Record<string, unknown>> = [
    {
      id: "alt-dispatch-901",
      timestamp: "Today, 08:30 IST",
      channel: "SMS + EMAIL",
      recipientPhone: "+91 98712 34567",
      recipientEmail: "citizen@delhi.gov.in",
      severity: "CRITICAL_EMERGENCY",
      title: "SEVERE AIR POLLUTION EMERGENCY: Anand Vihar AQI 442",
      smsMessageText:
        "[CAQM-ALERT] Anand Vihar AQI surged to 442 (Hazardous). Nocturnal inversion active. Wear N95 outdoors. Keep HEPA on. Helplines: 155255",
      emailSubject: "CRITICAL AIR EMERGENCY: Anand Vihar Air Quality Breaches 440 AQI [GRAP-III]",
      emailHtmlBody:
        "<h3>Commission for Air Quality Management (CAQM) &amp; Delhi Health Directorate</h3><p>Anand Vihar has reached 442 AQI. Wear N95 outdoors and keep HEPA filtration active.</p>",
      stationName: "Anand Vihar, East Delhi",
      aqiAtTrigger: 442,
      status: "DELIVERED",
      carrierGatewayId: "SMS-DEL-AIRTEL-48192",
      latencyMs: 14,
    },
  ];

  router.get("/health", (_req, res) => {
    res.json({
      status: "ok",
      timestamp: new Date().toISOString(),
      engine: "NVY AI — Delhi-NCR Environmental Intelligence Platform",
      aiArchitecture: "NVY In-House Deterministic Reasoning Engine (Zero External LLM Dependency)",
      mode: "STANDALONE_SELF_CONTAINED",
    });
  });

  router.get("/satellite-stream", (_req, res) => {
    const now = Date.now();
    const packetCounter = 3400 + Math.floor((now / 1000) % 900);
    const satNames = [
      "SENTINEL-5P (TROPOMI)",
      "SUOMI-NPP (VIIRS)",
      "INSAT-3DR (GEO-IMAGER)",
      "AQUA (MODIS)",
    ];

    res.json({
      success: true,
      timestamp: new Date().toISOString(),
      activeSatellite: satNames[Math.floor((now / 15000) % 4)],
      packetIngressRate: `${(3400 + (now % 250)).toLocaleString()} pkt/sec`,
      totalPacketsReceived: packetCounter,
      aerosolOpticalDepth: 0.82 + Number((Math.sin(now / 10000) * 0.05).toFixed(3)),
      no2ColumnTropospheric: "18.4 × 10¹⁵ molec/cm²",
      carbonMonoxideDensity: "2.85 × 10¹⁸ molec/cm²",
      smokePlumeAngle: 315,
      activeFarmFiresScanned: 23,
      streamStatus: "LIVE_STREAMING_1HZ",
    });
  });

  router.get("/alerts/subscription", (_req, res) => {
    res.json({ success: true, subscription: activeSubscription });
  });

  router.post("/alerts/subscribe", (req, res) => {
    const body = (req.body ?? {}) as Record<string, unknown>;
    if (body.emailAddress !== undefined && !isValidEmail(String(body.emailAddress))) {
      return res.status(400).json({ success: false, error: "Invalid email address format." });
    }
    if (body.phoneNumber !== undefined && !isValidPhone(String(body.phoneNumber))) {
      return res.status(400).json({ success: false, error: "Invalid phone number format." });
    }

    activeSubscription = {
      ...activeSubscription,
      phoneNumber: body.phoneNumber
        ? sanitizeString(body.phoneNumber, activeSubscription.phoneNumber, 20)
        : activeSubscription.phoneNumber,
      emailAddress: body.emailAddress
        ? sanitizeString(body.emailAddress, activeSubscription.emailAddress, 120)
        : activeSubscription.emailAddress,
      enableSms: typeof body.enableSms === "boolean" ? body.enableSms : activeSubscription.enableSms,
      enableEmail: typeof body.enableEmail === "boolean" ? body.enableEmail : activeSubscription.enableEmail,
      alertOnSevereAqi:
        typeof body.alertOnSevereAqi === "boolean" ? body.alertOnSevereAqi : activeSubscription.alertOnSevereAqi,
      aqiThreshold:
        body.aqiThreshold !== undefined
          ? clampNumber(body.aqiThreshold, 50, 500, activeSubscription.aqiThreshold)
          : activeSubscription.aqiThreshold,
      alertOnGrapEscalation:
        typeof body.alertOnGrapEscalation === "boolean"
          ? body.alertOnGrapEscalation
          : activeSubscription.alertOnGrapEscalation,
      alertOnNocturnalInversion:
        typeof body.alertOnNocturnalInversion === "boolean"
          ? body.alertOnNocturnalInversion
          : activeSubscription.alertOnNocturnalInversion,
      alertOnStubbleSurge:
        typeof body.alertOnStubbleSurge === "boolean"
          ? body.alertOnStubbleSurge
          : activeSubscription.alertOnStubbleSurge,
      dailyMorningDigest:
        typeof body.dailyMorningDigest === "boolean"
          ? body.dailyMorningDigest
          : activeSubscription.dailyMorningDigest,
      preferredLanguage: body.preferredLanguage === "HI" ? "HI" : "EN",
      updatedAt: new Date().toISOString(),
    };

    return res.json({
      success: true,
      message: "Emergency alert preferences updated successfully",
      subscription: activeSubscription,
    });
  });

  router.get("/alerts/history", (_req, res) => {
    res.json({ success: true, alerts: dispatchedAlertHistory });
  });

  router.post("/alerts/send-test", (req, res) => {
    const body = (req.body ?? {}) as Record<string, unknown>;
    const channel = ["SMS", "EMAIL", "SMS + EMAIL"].includes(String(body.channel))
      ? String(body.channel)
      : "SMS + EMAIL";
    const targetPhone =
      body.phone && isValidPhone(String(body.phone))
        ? sanitizeString(body.phone, activeSubscription.phoneNumber, 20)
        : activeSubscription.phoneNumber;
    const targetEmail =
      body.email && isValidEmail(String(body.email))
        ? sanitizeString(body.email, activeSubscription.emailAddress, 120)
        : activeSubscription.emailAddress;
    const targetAqi = clampNumber(body.aqi, 0, 999, 385);
    const station = sanitizeString(body.stationName, "Anand Vihar, East Delhi", 100);
    const severity = sanitizeString(body.severity, "CRITICAL_EMERGENCY", 40);

    const safeStationHtml = escapeHtml(station);
    const smsText = sanitizeString(
      body.customSmsText,
      `[CAQM-ALERT] URGENT: Air Quality at ${station} is ${targetAqi}. Wear N95 outdoors. Helplines: 155255`,
      320
    );
    const emailSubject = sanitizeString(
      body.customEmailSubject,
      `EMERGENCY ALERT: ${station} Breaches ${targetAqi} AQI [GRAP Stage-III]`,
      160
    );

    const emailBody = `<div style="font-family: Arial, sans-serif; background-color: #0d0d0d; color: #ffffff; padding: 20px; border: 2px solid #ef4444;">
      <h2 style="color: #ef4444; margin-top: 0;">CAQM &amp; DELHI HEALTH DIRECTIVES: AIR EMERGENCY</h2>
      <p><strong>Location:</strong> ${safeStationHtml}</p>
      <p><strong>Current AQI:</strong> ${targetAqi}</p>
    </div>`;

    const newAlert = {
      id: `alt-dispatch-${Date.now()}`,
      timestamp: `Just now (${new Date().toLocaleTimeString("en-IN", { timeZone: "Asia/Kolkata" })} IST)`,
      channel,
      recipientPhone: targetPhone,
      recipientEmail: targetEmail,
      severity,
      title: `${severity === "GRAP_ENFORCEMENT" ? "GRAP DIRECTIVE" : "AIR EMERGENCY"}: ${station} (AQI ${targetAqi})`,
      smsMessageText: smsText,
      emailSubject,
      emailHtmlBody: emailBody,
      stationName: station,
      aqiAtTrigger: targetAqi,
      status: "DELIVERED",
      carrierGatewayId: `GW-DEL-${Math.floor(10000 + Math.random() * 90000)}`,
      latencyMs: 16,
    };

    dispatchedAlertHistory.unshift(newAlert);
    if (dispatchedAlertHistory.length > 30) {
      dispatchedAlertHistory = dispatchedAlertHistory.slice(0, 30);
    }

    res.json({
      success: true,
      message: `Emergency alert dispatched successfully via ${channel}`,
      dispatchedAlert: newAlert,
    });
  });

  const postHandlers: Array<{ path: string; label: string; fn: (input: Record<string, unknown>) => unknown }> = [
    { path: "/ai-precautions-advisory", label: "precaution advisory", fn: runAdvisoryEngine },
    { path: "/alerts/ai-compose", label: "emergency alert", fn: composeEmergencyAlert },
    { path: "/policy-ai-simulation", label: "policy simulation", fn: runPolicyEngine },
    { path: "/forecast-reasoning", label: "forecast reasoning", fn: runForecastEngine },
    { path: "/generate-report", label: "policy briefing report", fn: generatePolicyBriefingReport },
    { path: "/chat-ai", label: "chat query", fn: runChatEngine },
    { path: "/commute-exposure", label: "commute exposure", fn: runExposureEngine },
    { path: "/indoor-optimization", label: "indoor CADR optimization", fn: runCadrEngine },
    { path: "/institutional-guidelines", label: "institutional guidelines", fn: runInstitutionalEngine },
    { path: "/voice-briefing-text", label: "voice briefing script", fn: generateVoiceScript },
  ];

  for (const { path: routePath, label, fn } of postHandlers) {
    router.post(routePath, (req, res) => {
      try {
        res.json(fn((req.body ?? {}) as Record<string, unknown>));
      } catch {
        res.status(500).json({ success: false, error: `Failed to process ${label}` });
      }
    });
  }

  router.get("/source-attribution", (_req, res) => {
    try {
      res.json({ success: true, ...runSourceAttributionEngine() });
    } catch {
      res.status(500).json({ success: false, error: "Failed to compute source attribution" });
    }
  });

  return router;
}
